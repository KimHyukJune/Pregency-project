from datetime import datetime
import firebase_admin
from firebase_admin import credentials

PROJECT_ID = "pregency-7d66b"
cred = credentials.Certificate("./Pregency.json")
default_app = firebase_admin.initialize_app(cred, {'storageBucket': f"{PROJECT_ID}.appspot.com"})

from bluetooth import *
import RPi.GPIO as GPIO
import time
import mq7values as sr
import math
import cv2
import json
import requests
from PIL import Image
from io import BytesIO
from flask import Flask, Response
from CameraService import CameraService
from Amg8833 import Amg8833
from uuid import uuid4
from firebase_admin import storage
from firebase_admin import firestore
from threading import Timer

app = Flask(__name__)
cap = CameraService(0)
cap.start()

amg8833 = Amg8833()
socket = BluetoothSocket(RFCOMM)
socket.connect(("7C:9E:BD:4B:6E:76", 1))
print("bluetooth connected!")

PAGE = """\
<html>
<head>
<title>Tema : Pregency</title>
</head>
<body>
<center><h1>Product : Keeper</h1></center>
<center><img src="stream.mjpg" width="640" height="480"></center>
<center><img src="stream1.mjpg" width="640" height="480"></center>
</body>
</html>
"""

standard = 500
high = 800
fire1 = 'on'
fire2 = 'off'

channel = 21
GPIO.setmode(GPIO.BCM)
GPIO.setup(channel, GPIO.IN)


def fire(channel):
    print(fire1)


GPIO.add_event_detect(channel, GPIO.BOTH, bouncetime=300)
GPIO.add_event_callback(channel, fire)

def firemq7():
    try:
        readData = sr.analog_read(1)
        mq7 = readData
        print(mq7)
        db = firestore.client()
        if mq7 > high or fire(1):
            arduino = "2"
            socket.send(arduino)
            print(arduino)
            print("high")
            print("-------------------------------------------------------")

        elif mq7 > standard:
            arduino = "1"
            socket.send(arduino)
            print(arduino)
            print("nolmal")
            print("-------------------------------------------------------")

            doc_ref = db.collection(u'machines').document(u'iot1')
            doc_ref.update({
                u'sensorvalue': "1"
            })

        elif mq7 < standard:
            arduino = "0"
            socket.send(arduino)
            print(arduino)
            print("low")
            print("-------------------------------------------------------")
            doc_ref = db.collection(u'machines').document(u'iot1')
            doc_ref.update({
                u'sensorvalue': "0"
            })
        time.sleep(0.1)
    except Exception as err:
        print(err)
    Timer(0.8, firemq7).start()
firemq7()

"------------------------------------------------------------------------------"


@app.route("/")
def hello_world():
    return str(amg8833.read_temp()) + PAGE


def cameraRead(camera):
    while True:
        frame = camera.read()
        if frame is not None:
            imgRGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            jpg = Image.fromarray(imgRGB)
            content = BytesIO()
            jpg.save(content, 'JPEG')
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + content.getvalue() + b'\r\n')


def amg8833Read():
    while True:
        frame = amg8833.get_img()
        if frame is not None:
            jpg = Image.fromarray(frame)
            content = BytesIO()
            jpg.save(content, 'JPEG')
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + content.getvalue() + b'\r\n')


@app.route('/stream.mjpg')
def stream():
    response = Response(cameraRead(cap),
                        mimetype='multipart/x-mixed-replace; boundary=frame')
    return response


@app.route('/stream1.mjpg')
def stream1():
    response = Response(amg8833Read(),
                        mimetype='multipart/x-mixed-replace; boundary=frame')
    return response


if __name__ == '__main__':
    app.run(threaded=True)